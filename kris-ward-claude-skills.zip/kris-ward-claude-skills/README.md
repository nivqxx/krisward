# Kris Ward / Win The Hour Win The Day — Claude Code Skills

Claude Code skill for Maura's work running the WIN leadership program: weekly video reviews and Loom feedback, STK (SuperToolKit) audits, WhatsApp daily pulses, reminder emails, monthly report cards, and the leadership program tracker.

## Contents

- **kris-leadership-program** — the main skill (language rules, feedback structure, STK audits, workflows)
  - `references/report-cards.md` — monthly report card template, scoring, notes voice, and the send pipeline
  - `references/program-resources.md` — links to the tracker sheet, scorecard folders, and invoice templates in Google Drive

## Usage with Claude Code

**Option A — per project:** clone this repo (or copy the `.claude/` folder into any project). Skills in `.claude/skills/` load automatically when you run `claude` in that directory.

**Option B — global (all projects):** copy the skill folder to `~/.claude/skills/`:

```bash
cp -r .claude/skills/* ~/.claude/skills/
```

Then mention Kris Ward / WIN team work in Claude Code and the skill triggers automatically.

Note: workflows that touch Gmail, Google Drive, Notion, Basecamp, or WhatsApp need those connections set up in Claude Code (MCP servers) — the skill describes the process either way.
