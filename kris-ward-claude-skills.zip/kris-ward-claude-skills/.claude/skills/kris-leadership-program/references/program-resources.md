# Kris Ward Program — Key Resources (Google Drive)

| Resource | What it is | Link |
|---|---|---|
| WIN Team Leadership Program 2026 | Central tracker sheet: leadership questions x members (team leader in parentheses), submission dates, video links, Maura's feedback links | https://docs.google.com/spreadsheets/d/1hwUGeCKi13lBYx4Gfx60wgr4y4_m9wsnxMm3JSDTssk |
| Active WIN Team Members | Drive folder with per-member scorecard subfolders | https://drive.google.com/drive/folders/1CivwDZfzmz9ygFj8t0OmGRD0bNzPMGCM |
| Leadership Program Progress Report (Gab, example) | Report card Google Doc template in use | https://docs.google.com/document/d/14GC7yIGVdSk5uiuRzP6FMljEva-seSF2SI8egt0134c |
| Leadership Program Progress Report (Diane, example) | Second example report card | https://docs.google.com/document/d/1FUFOve5J_sLhw-Nu1Med5_YEQ5f0SB8XFG29Hbl--hg |
| WTH WTD Team Invoice Template (Maura's copy) | Invoice template for the team | https://docs.google.com/spreadsheets/d/1eifYsuko3iZRmKqNUu6A0Kxxr5CEhig6GTg0quTs3_8 |
| WTH WTD Team Invoice Template (Kris's original) | Source template owned by Kris | https://docs.google.com/spreadsheets/d/12m6qBXljm3MO28ZInIc_ijmvgIr3zZctvGNpNCCX1z4 |

## Tracker conventions

- Member columns are headed `Name (Team Leader)`, e.g. `Gab (Reb)`.
- Each leadership question row has: a cell that flips from "Video Link" placeholder to the submission date + video URL (Loom, Tella, or Drive) when submitted, and a "Maura link" row beneath for Maura's feedback video link.
- Feedback videos are recorded on Loom or Tella.
