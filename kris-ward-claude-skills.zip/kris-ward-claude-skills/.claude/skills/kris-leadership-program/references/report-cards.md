# Monthly Report Cards (Leadership Program Progress Reports)

Each WIN team member gets a monthly "Leadership Program Progress Report" (report card). Google Docs live in each member's scorecard folder in Drive (e.g. `Gab_Layson_Scorecard`, `Diane_May_Dugay_Scorecard`), owned by kris@shadowblast.com.

## Template Structure

Header: **WIN Team Member Name** (note seniority, e.g. "Senior WIN Team Member") and **Month**.

| # | Section | Score scale |
|---|---------|-------------|
| 1 | Participation — Monthly Live attendance (Yes/No) + Weekly Leadership Pulse | 1–5 |
| 2 | Communication | 1–5 |
| 3 | Initiative | 1–5 |
| 4 | Monthly Theme Focus | 0–1 |
| 5 | Learning Center Engagement | 1–5 |
| 6 | Super Toolkit | 0–1 |
| 7 | Leadership Video | 0–1 |
| 8 | Growth & Engagement | 1–5 |

Then **Special Notes** (personal paragraph, names the member, cites specifics like number of videos submitted) and **Total Score** as a percentage.

Each section has a fixed "We look for:" bullet list (part of the template — don't rewrite) followed by **Score** and **Notes**.

## Notes voice

Warm, direct, second person, italicized, 1–2 sentences. Affirm the behavior and tie it to leadership identity. Examples from real reports:

- *"You keep us informed with steady updates. That kind of transparency is a real leadership skill."*
- *"You treat the Learning Center as a real career tool, not just training to get through."*
- *"You use your leadership videos as real practice, and it shows. Your communication gets stronger every time."*

If a program component is paused, score it 0 with a note like: *"On pause for restructuring. Progress not affected."*

## Monthly pipeline (as run for June 2026)

1. Fill out each member's scorecard/progress report doc for the month
2. Export each to PDF
3. Email each member from Maura's Gmail:
   - **To:** the member; **CC:** their team leader; **BCC:** Kris on all (Kate additionally BCC'd on Diane's)
   - Subject and body follow Maura's monthly report card email template (month-specific)
   - Attach the member's PDF
   - PS variants: congrats PS for the top performer(s); encouragement PS for lower scorers
4. Verify all sent in Gmail Sent folder (count must match member count — 13 in June)

## Roster (2026 tracker: member → team leader)

Cristina (Danna), Diane (Kate), Ellysa (Raeanne), Gab (Reb), Iris (Danna), Jade (Matt), Joas (Tracy), Jopene (Karen Laws), Mae (Nikki), Marie (Kristi), MJ (Karen), Novi (Matt), Rafael (Danna), Sheena (Sarra), Shiela (Clarice), Stephanie (Tash), Vena (Karen), Wally (Peter), Zach (Reb), Zeychelle (Danna).

Note: the tracker lists 20 columns but only 13 report card emails went out in June — confirm the active member list before each monthly run.
