# Claude Setup — Transfer Documentation

**Purpose:** Complete record of the current Claude environment (custom skills, plugins, connectors, and configuration) so it can be rebuilt on a different Claude Code account.

**Generated:** 2026-07-14

---

## How to use this package

This package contains everything needed to recreate the setup:

```
claude-transfer/
├── SETUP-DOCUMENTATION.md          ← this file (the full inventory + instructions)
└── custom-skills/                  ← your custom skills, ready to copy over
    ├── scrum-analysis/
    │   ├── SKILL.md
    │   └── references/leadership-frameworks.md
    ├── viral-hook-writer/
    │   └── SKILL.md
    └── wrapup/
        └── SKILL.md
```

Three things move between accounts, and each moves differently:

1. **Custom skills** → copy the folders in `custom-skills/` into the new account's skills directory (files are included here — direct copy).
2. **Plugins** → reinstall from the plugin marketplace on the new account (files are NOT copied; they come from the marketplace).
3. **Connectors (MCP servers)** → reconnect via OAuth in the new account's settings (credentials are account-bound and cannot be exported).

Built-in/public skills need no action — they ship with every account.

---

## 1. Custom skills (MUST be manually transferred)

These are your own skills. They do **not** exist on a fresh account. The full files are included in `custom-skills/` in this package — copy them into the new account's user skills folder (typically `~/.claude/skills/` or the equivalent user skills directory for your setup).

### 1a. `scrum-analysis`
- **What it does:** Analyses scrum meeting transcripts through three lenses — Scrum methodology (Sutherland), leadership coaching (Braswell), and language mechanics — to give leadership feedback.
- **Triggers:** "analyse my scrum", "how did my scrum go", "review this meeting", "leadership feedback on this call", "scrum feedback", "review my meeting with Sheena".
- **Files:** `SKILL.md` + `references/leadership-frameworks.md` (11 diagnostic frameworks: Manager vs Leader polarity, COACH, SBI/SBIP, 3-Layer Spark Questions, Autonomy Model, 12 Leadership Shifts, language shifts, Servant Ownership, meeting leadership, Bunny→BEAR, Scrum structural checklist).
- **Personalised context baked in:** Built for Sarra, who runs a two-person ghostwriting business with a remote VA (Sheena) across the UK and Philippines. References Jeff Sutherland's Scrum book and Dwight Braswell's leadership frameworks expected in project knowledge.
- **Note:** This skill also expects Scrum reference material (Sutherland's book) and Braswell's frameworks to live in the **project knowledge** on the new account. The `references/leadership-frameworks.md` file travels with the skill, but if you relied on a separate project file for the Sutherland book, re-add that to the new project too.

### 1b. `viral-hook-writer`
- **What it does:** Generates 11 LinkedIn hooks (one per proven format template) plus a "Top 3 Picks" recommendation. Collects topic, target audience, and proof points before writing.
- **Triggers:** "write me a hook", "hook ideas", "LinkedIn opener", "help me start my post", "viral hooks", "scroll-stopping hooks".
- **Files:** `SKILL.md` (self-contained — all 11 formats and rules are inside).

### 1c. `wrapup`
- **What it does:** End-of-session routine — summarises the session, saves memories, and pushes a session log to a NotebookLM "AI Brain" notebook.
- **Triggers:** `/wrapup`, "wrap up", "save this session", "end of session", "session summary".
- **Files:** `SKILL.md` (self-contained).
- **⚠️ External dependency — this skill will NOT fully work on the new account until you set up its tooling:**
  1. Install the CLI: `pip install "notebooklm-py[browser]"` then `playwright install chromium`
  2. Authenticate: `notebooklm login`
  3. On first run it looks for a memory file storing `brain_notebook_id`. If none exists it offers to create an "AI Brain" notebook via `notebooklm create "[Name]'s AI Brain" --json` and saves the ID to `reference_brain_notebook.md`.
  - The CLI path fallback it uses is `~/.notebooklm-venv/bin/notebooklm`.
  - **Your existing "AI Brain" NotebookLM notebook lives in your NotebookLM account, not in Claude.** It transfers automatically as long as the new Claude account authenticates to the same NotebookLM/Google account. If you want history preserved, keep using the same NotebookLM notebook ID.

---

## 2. Plugins (reinstall from marketplace — files are NOT copied)

Two plugins are installed. Plugin skills are managed by the plugin system, so you reinstall the plugin on the new account rather than copying files. Install the same plugins and all their skills return automatically.

### Plugin: `marketing`
Marketing content and strategy suite. Skills included:
- `marketing:performance-report` — marketing performance reports with metrics, trends, wins/misses, prioritised recommendations.
- `marketing:campaign-plan` — full campaign brief with objectives, audience, messaging, channel strategy, content calendar, metrics.
- `marketing:draft-content` — drafts blog posts, social, email, landing pages, press releases, case studies with SEO recs.
- `marketing:content-creation` — channel-specific content drafting (overlaps with draft-content; both present).
- `marketing:seo-audit` — keyword research, on-page analysis, content gaps, technical checks, competitor comparison.
- `marketing:competitive-brief` — competitor research, positioning/messaging comparison, battlecards.
- `marketing:brand-review` — reviews content against brand voice/style guide, flags deviations by severity with before/after fixes.
- `marketing:email-sequence` — multi-email sequences with copy, timing, branching logic, benchmarks.

### Plugin: `cowork-plugin-management`
Tools for building and customising Claude Code plugins. Skills included:
- `cowork-plugin-management:cowork-plugin-customizer` — customise a plugin for a specific org's tools/workflows.
- `cowork-plugin-management:create-cowork-plugin` — guide creating a new plugin from scratch (requires Cowork mode).

**Transfer action:** On the new account, open the plugin marketplace / plugin manager and install `marketing` and `cowork-plugin-management`. If either is a private/org plugin, you'll need access to the same source it was installed from.

---

## 3. Connectors / MCP servers (reconnect via OAuth)

These integrations are connected on the current account. **Credentials cannot be exported** — on the new account, go to Settings → Connectors and reconnect each one (you'll re-authenticate via OAuth). The list below is what to reconnect:

| Connector | MCP URL |
|---|---|
| Descript | https://api.descript.com/v2/mcp/claude |
| Gmail | https://gmailmcp.googleapis.com/mcp/v1 |
| Google Calendar | https://calendarmcp.googleapis.com/mcp/v1 |
| Google Drive | https://drivemcp.googleapis.com/mcp/v1 |
| Granola | https://mcp.granola.ai/mcp |
| monday.com | https://mcp.monday.com/mcp |
| Notion | https://mcp.notion.com/mcp |

**Notes:**
- Reconnect to the **same underlying accounts** (same Google account for Gmail/Calendar/Drive, same Notion workspace, etc.) so existing data and the `wrapup` NotebookLM Brain remain accessible.
- The `wrapup` skill's NotebookLM push depends on the NotebookLM CLI auth (section 1c), which is separate from these MCP connectors.

---

## 4. Built-in / public skills (no action needed)

These ship with every Claude account. Listed only so the inventory is complete — do **not** copy them; they'll already be present on the new account.

- `docx` — create/read/edit Word documents.
- `pdf` — create, fill, merge, split, watermark, encrypt PDFs.
- `pptx` — create/read/edit PowerPoint presentations.
- `xlsx` — create/read/edit spreadsheets.
- `product-self-knowledge` — verified Anthropic product facts.
- `frontend-design` — visual design guidance for UI.
- `file-reading` — router for reading uploaded files.
- `pdf-reading` — reading/extracting content from PDFs.
- `skill-creator` — create/modify/measure skills.

---

## 5. Transfer checklist

On the new account, work through this in order:

- [ ] **Custom skills:** Copy `custom-skills/scrum-analysis/`, `custom-skills/viral-hook-writer/`, and `custom-skills/wrapup/` into the new account's user skills directory (preserve the `references/` subfolder inside `scrum-analysis`).
- [ ] **scrum-analysis project knowledge:** Re-add any separate Scrum reference (Sutherland's book) and Braswell's frameworks to the project if you kept them as project files.
- [ ] **Plugins:** Install `marketing` and `cowork-plugin-management` from the plugin marketplace.
- [ ] **Connectors:** Reconnect all 7 MCP servers (section 3) via Settings → Connectors, authenticating to the same accounts.
- [ ] **wrapup tooling:** `pip install "notebooklm-py[browser]"`, `playwright install chromium`, then `notebooklm login`. Point it at the same "AI Brain" notebook to keep history.
- [ ] **Verify:** Trigger each custom skill once ("write me a hook", "analyse my scrum", "/wrapup") to confirm they load and run.

---

## 6. What could NOT be captured here

For honesty about the limits of this export:

- **Connector credentials / OAuth tokens** — never exportable; must be re-authenticated.
- **Past conversation history and memories** — not included in this file. If you have saved memory files (e.g. `MEMORY.md`, `reference_brain_notebook.md`) in your working environment, export those separately; they're referenced by the `wrapup` skill but live outside the skill folder.
- **Plugin source/marketplace access** — if `marketing` or `cowork-plugin-management` came from a private source, you need the same access on the new account.
- **Project-level files and knowledge bases** — anything uploaded into a specific project (e.g. the Sutherland Scrum book) lives in the project, not the skill, and must be re-uploaded.

If any of those matter for your transfer, tell me which and I can help you pull them together.
